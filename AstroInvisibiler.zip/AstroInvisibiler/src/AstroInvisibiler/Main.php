<?php

declare (strict_types=1);

namespace AstroInvisibiler;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Effect;
use pocketmine\entity\Living;
use pocketmine\utils\TextFormat as TF;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\item;
use pocketmine\item\ItemIds;
use pocketmine\entity\EntityEvent;


class Main extends PluginBase implements Listener {
	
	/** @var Effect[] */
	protected static $effects = [];
	
	/**
	 * @param Effect $effects
	 */
	public static function registerEffect(Effects $effects) : void{
		self::$effects[$effects->getId()] = $effects;
	}

	public function onEnable()
	{
		$this->getServer()->getLogger()->info(TF::GREEN . "AstroInvisibiler made by TurtleSh0ck was successfully enabled");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
         public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch ($command->getName()) {

            case "ai":
                if ($sender instanceof Player) {
                    if (empty($args[0])) {
                        $sender->sendMessage(TF::RED . "Usage: /ai give (player) (amount)");
                        return true;
                    }
                    switch ($args[0]) {
                        case "give":
                            if (empty($args[1])) {
                                $sender->sendMessage(TF::RED . "Usage: /ai give (player) (amount)");
                                return true;
                            }
                            $player = $this->getServer()->getPlayer($args[1]);
                            if ($player === null) {
                                $sender->sendMessage(TF::RED . "Player is offline");
                                return true;
                            }
                            $netherstar = Item::get(Item::NETHERSTAR);
                            $netherstar->setCustomName(TF::DARK_GREEN . "§lHamodk08's Invisibiler");
                            $netherstar->setLore([TF::GREEN . "§2§lTap to get 5 sec invisibility!\n\n§l§7[§cRARE ITEM§r§7]"]);
                            if (empty($args[2])) {
                                $sender->sendMessage(TF::RED . "Usage: /ai give (player) (amount)");
                                return true;
                            }
                            for ($count = $args[2] ?? 1; $count > 0; --$count) {
                                $player->getInventory()->addItem(clone $netherstar); 
    
                            }
                    }
                }
        }
        return true;
    }

                        public function onInteract(PlayerInteractEvent $event) {
                        if($event->getItem()->getId() === 399) {       	$player = $event->getPlayer();
                        $item = $event->getItem();
                        $player = $event->getPlayer();
                        $inv = $player->getInventory();
                        $item = $inv->getItemInHand();
                        $item->count--;
                        $inv->setItemInHand($item);
                        $effect = new EffectInstance(Effect::getEffect(Effect::INVISIBILITY));
                        $effect->setDuration(2400)->setAmplifier(1)->setVisible(true);
                        $player->addEffect($effect); 
        
      }                   
   }
}
